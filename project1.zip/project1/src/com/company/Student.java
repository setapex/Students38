package com.company;

public class Student {

    private String name;
    private int age;
    private Address address;

    public Student(String name, int age, Address address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public void info() {
        System.out.println(name + " " + age + " " + address.adres());
    }

    public void setName(String name) {

        this.name = name;
    }

    public void setAge(int age) {

        this.age = age;
    }

    public void setAddress(Address address) {

        this.address = address;
    }

    public String getName() {

        return name;
    }

    public int getAge() {

        return age;
    }

    public Address getAddress() {

        return address;
    }
    public String student(){return name+" "+age;}
}
